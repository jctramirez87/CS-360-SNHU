package com.example.weighttrackerjessicaramirez;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    private List<WeightEntry> weightEntries;
    private OnItemLongClickListener longClickListener;

    // Interface for long-click events
    public interface OnItemLongClickListener {
        void onItemLongClick(WeightEntry entry);
    }

    // Constructor with data and listener
    public WeightAdapter(List<WeightEntry> weightEntries, OnItemLongClickListener listener) {
        this.weightEntries = weightEntries;
        this.longClickListener = listener;
    }

    @NonNull
    @Override
    public WeightAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_2, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightAdapter.ViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);
        holder.dateText.setText("Date: " + entry.getDate());
        holder.weightText.setText("Weight: " + entry.getWeight() + " lbs");

        // Handle long-click on item
        holder.itemView.setOnLongClickListener(v -> {
            longClickListener.onItemLongClick(entry);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateText;
        TextView weightText;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            dateText = itemView.findViewById(android.R.id.text1);
            weightText = itemView.findViewById(android.R.id.text2);
        }
    }
}
