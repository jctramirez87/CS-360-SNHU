package com.example.weighttrackerjessicaramirez;

import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DataGridActivity extends AppCompatActivity {

    private RecyclerView weightRecyclerView;
    private DatabaseHelper dbHelper;
    private WeightAdapter adapter;
    private List<WeightEntry> weightEntryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_grid);

        weightRecyclerView = findViewById(R.id.weightRecyclerView);
        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DatabaseHelper(this);

        Button addWeightButton = findViewById(R.id.addWeightButton);
        addWeightButton.setOnClickListener(v -> showAddWeightDialog());

        // Button to set goal weight
        Button setGoalButton = findViewById(R.id.setGoalButton);
        setGoalButton.setOnClickListener(v -> showSetGoalWeightDialog());

        Button setPhoneNumberButton = findViewById(R.id.setPhoneNumberButton);
        setPhoneNumberButton.setOnClickListener(v -> showSetPhoneNumberDialog());


        loadData();
    }

    private void loadData() {
        Cursor cursor = dbHelper.getAllWeightEntries();
        weightEntryList = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String date = cursor.getString(1);
                float weight = cursor.getFloat(2);
                weightEntryList.add(new WeightEntry(id, date, weight));
            } while (cursor.moveToNext());
        }
        cursor.close();

        adapter = new WeightAdapter(weightEntryList, this::showEntryOptionsDialog);
        weightRecyclerView.setAdapter(adapter);
    }

    private void showAddWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Weight Entry");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText dateInput = new EditText(this);
        dateInput.setHint("Date (e.g., 2025-04-19)");
        layout.addView(dateInput);

        final EditText weightInput = new EditText(this);
        weightInput.setHint("Weight (lbs)");
        weightInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        layout.addView(weightInput);

        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String date = dateInput.getText().toString();
            String weightStr = weightInput.getText().toString();
            if (!date.isEmpty() && !weightStr.isEmpty()) {
                try {
                    float weight = Float.parseFloat(weightStr);
                    boolean success = dbHelper.addWeightEntry(date, weight);
                    if (success) {
                        Toast.makeText(this, "Entry added", Toast.LENGTH_SHORT).show();
                        loadData();

                        if (weight <= getGoalWeight() && getGoalWeight() > 0) {
                            sendGoalReachedSMS(weight);
                        }
                    } else {
                        Toast.makeText(this, "Error adding entry", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showEntryOptionsDialog(WeightEntry entry) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Entry Options")
                .setItems(new CharSequence[]{"Edit", "Delete", "Cancel"}, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            showEditWeightDialog(entry);
                            break;
                        case 1:
                            boolean deleted = dbHelper.deleteWeightEntry(entry.getId());
                            if (deleted) {
                                Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
                                loadData();
                            } else {
                                Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
                            }
                            break;
                        default:
                            dialog.dismiss();
                    }
                });
        builder.show();
    }

    private void showEditWeightDialog(WeightEntry entry) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Weight Entry");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText dateInput = new EditText(this);
        dateInput.setHint("Date (e.g., 2025-04-19)");
        dateInput.setText(entry.getDate());
        layout.addView(dateInput);

        final EditText weightInput = new EditText(this);
        weightInput.setHint("Weight (lbs)");
        weightInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        weightInput.setText(String.valueOf(entry.getWeight()));
        layout.addView(weightInput);

        builder.setView(layout);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newDate = dateInput.getText().toString();
            String newWeightStr = weightInput.getText().toString();
            if (!newDate.isEmpty() && !newWeightStr.isEmpty()) {
                try {
                    float newWeight = Float.parseFloat(newWeightStr);
                    boolean updated = dbHelper.updateWeightEntry(entry.getId(), newDate, newWeight);
                    if (updated) {
                        Toast.makeText(this, "Entry updated", Toast.LENGTH_SHORT).show();
                        loadData();

                        if (newWeight <= getGoalWeight() && getGoalWeight() > 0) {
                            sendGoalReachedSMS(newWeight);
                        }
                    } else {
                        Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showSetGoalWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Goal Weight");

        final EditText input = new EditText(this);
        input.setHint("Enter goal weight (lbs)");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String inputStr = input.getText().toString();
            if (!inputStr.isEmpty()) {
                try {
                    float goal = Float.parseFloat(inputStr);
                    getSharedPreferences("WeightPrefs", MODE_PRIVATE)
                            .edit().putFloat("goal_weight", goal).apply();
                    Toast.makeText(this, "Goal weight saved: " + goal + " lbs", Toast.LENGTH_SHORT).show();
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private float getGoalWeight() {
        return getSharedPreferences("WeightPrefs", MODE_PRIVATE)
                .getFloat("goal_weight", 0);
    }

    private void sendGoalReachedSMS(float currentWeight) {
        String phoneNumber = getSharedPreferences("WeightPrefs", MODE_PRIVATE)
                .getString("user_phone", null);

        if (phoneNumber == null || phoneNumber.isEmpty()) {
            Toast.makeText(this, "Phone number not set. Cannot send SMS.", Toast.LENGTH_LONG).show();
            return;
        }

        String message = "🎉 Congrats! You've reached your goal weight of " + currentWeight + " lbs!";

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Goal reached! SMS sent.", Toast.LENGTH_SHORT).show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS}, 101);
            Toast.makeText(this, "SMS permission not granted. Goal alert not sent.", Toast.LENGTH_LONG).show();
        }
    }

    private void showSetPhoneNumberDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Phone Number");

        final EditText input = new EditText(this);
        input.setHint("Enter your phone number");
        input.setInputType(InputType.TYPE_CLASS_PHONE);

        // Pre-fill the input with the saved number (if any)
        String savedNumber = getSharedPreferences("WeightPrefs", MODE_PRIVATE)
                .getString("user_phone", "");
        input.setText(savedNumber);

        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String number = input.getText().toString().trim();
            if (!number.isEmpty()) {
                getSharedPreferences("WeightPrefs", MODE_PRIVATE)
                        .edit().putString("user_phone", number).apply();
                Toast.makeText(this, "Phone number saved: " + number, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Phone number cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}
